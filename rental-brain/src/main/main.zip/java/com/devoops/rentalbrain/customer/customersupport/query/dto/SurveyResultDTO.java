package com.devoops.rentalbrain.customer.customersupport.query.dto;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class SurveyResultDTO {
    private Long id;
    private String aiResponse;
}
