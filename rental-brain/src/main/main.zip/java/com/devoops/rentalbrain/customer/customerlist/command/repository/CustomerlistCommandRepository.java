package com.devoops.rentalbrain.customer.customerlist.command.repository;

import com.devoops.rentalbrain.customer.customerlist.command.entity.CustomerlistCommandEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

public interface CustomerlistCommandRepository extends JpaRepository<CustomerlistCommandEntity, Long> {

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query(value = """
    UPDATE 
           customer A
       SET A.segment_id = 2
     WHERE A.segment_id = 1
       AND EXISTS (
           SELECT 1
           FROM contract B
           WHERE B.cum_id = A.id
      )
    """, nativeQuery = true)
    int bulkPromotePotentialToNew();

}