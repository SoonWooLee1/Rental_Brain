package com.devoops.rentalbrain.common.segmentrebuild.quartz;


import com.devoops.rentalbrain.customer.customerlist.command.repository.CustomerlistCommandRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class SegmentBatchCommandService {
    private final CustomerlistCommandRepository customerlistCommandRepository;

    @Transactional
    public int fixPotentialToNew() {
        return customerlistCommandRepository.bulkPromotePotentialToNew();
    }
}
